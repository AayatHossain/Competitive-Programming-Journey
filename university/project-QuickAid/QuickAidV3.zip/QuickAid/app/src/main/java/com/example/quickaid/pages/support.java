package com.example.quickaid.pages;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.quickaid.R;

public class support extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.support);
    }
}
