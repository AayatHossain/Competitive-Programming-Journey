package com.example.quickaid.pages;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.quickaid.R;

public class guide extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.guide_design);
    }
}
