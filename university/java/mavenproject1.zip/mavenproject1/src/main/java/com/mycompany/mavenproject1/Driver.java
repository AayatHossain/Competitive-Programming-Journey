/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject1;

/**
 *
 * @author User
 */
public class Driver {
    int driver_id;
    String name;
    int rating;
    Driver(int driver_id, String name, int rating){
        this.driver_id = driver_id;
        this.name = name;
        this.rating = rating;
    }
}
