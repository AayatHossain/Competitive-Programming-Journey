/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject1;

/**
 *
 * @author User
 */
public class Vehicle {
    int vehicle_id;
    int model;
    int capacity;
    Vehicle(int id, int model, int cap){
        this.vehicle_id = id;
        this.model = model;
        this.capacity = cap;
    }
}
